
export default {
  root: '.',
  server: {
    open: true
  }
}
