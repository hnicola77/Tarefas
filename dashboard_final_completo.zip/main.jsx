
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import Papa from 'papaparse';
import Chart from 'chart.js/auto';
import { CategoryScale } from 'chart.js';

Chart.register(CategoryScale);

function Dashboard() {
  const [data, setData] = useState([]);
  const [filtros, setFiltros] = useState({ Diretoria: '', Gerente: '', Grupo: '', Suprimentos: '' });

  useEffect(() => {
    fetch('/base_filtrada_para_powerbi.csv')
      .then(res => res.text())
      .then(csv => {
        const parsed = Papa.parse(csv, { header: true, dynamicTyping: true });
        setData(parsed.data.filter(row => row.Total && row.Atrasado));
      });
  }, []);

  const aplicarFiltros = () => {
    return data.filter(row => {
      return (
        (!filtros.Diretoria || row.Diretoria === filtros.Diretoria) &&
        (!filtros.Gerente || row.Gerente === filtros.Gerente) &&
        (!filtros.Grupo || row.Grupo === filtros.Grupo) &&
        (!filtros.Suprimentos || row.Suprimentos === filtros.Suprimentos)
      );
    });
  };

  const renderChart = () => {
    const ctx = document.getElementById('chart');
    if (!ctx) return;
    if (Chart.getChart('chart')) Chart.getChart('chart').destroy();

    const agrupado = {};
    aplicarFiltros().forEach(row => {
      const key = row['Centro de Custo'] || 'Não informado';
      if (!agrupado[key]) agrupado[key] = { total: 0, atrasado: 0 };
      agrupado[key].total += parseInt(row.Total || 0);
      agrupado[key].atrasado += parseInt(row.Atrasado || 0);
    });

    const labels = Object.keys(agrupado);
    const totais = labels.map(l => agrupado[l].total);
    const atrasos = labels.map(l => agrupado[l].atrasado);

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Total de Tarefas', data: totais, backgroundColor: 'steelblue' },
          { label: 'Tarefas Atrasadas', data: atrasos, backgroundColor: 'indianred' }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          title: { display: true, text: 'Tarefas por Centro de Custo' },
          legend: { position: 'top' },
          tooltip: { enabled: true },
          datalabels: {
            anchor: 'end',
            align: 'end',
            formatter: Math.round
          }
        },
        scales: {
          x: { stacked: true },
          y: { beginAtZero: true }
        }
      }
    });
  };

  useEffect(() => {
    if (data.length) renderChart();
  }, [data, filtros]);

  const gerarOpcoes = (campo) => {
    const unicos = [...new Set(data.map(row => row[campo]).filter(Boolean))];
    return [''].concat(unicos);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Dashboard de Tarefas</h1>

      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 20 }}>
        {['Diretoria', 'Gerente', 'Grupo', 'Suprimentos'].map(campo => (
          <div key={campo}>
            <label>{campo}:</label>
            <select
              value={filtros[campo]}
              onChange={e => setFiltros({ ...filtros, [campo]: e.target.value })}
            >
              {gerarOpcoes(campo).map(op => (
                <option key={op} value={op}>{op || 'Todos'}</option>
              ))}
            </select>
          </div>
        ))}
      </div>

      <canvas id="chart" height="300"></canvas>
    </div>
  );
}

const root = createRoot(document.getElementById('root'));
root.render(<Dashboard />);
